package org.noos.xing.yasaf.bean;

/**
 * @author Angelo De Caro (angelo.decaro@gmail.com)
 */
public interface Invocation {

    Object getTarget();

    Object[] getArgs();
}
