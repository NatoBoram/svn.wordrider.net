package org.noos.common;

/**
 * @author Angelo De Caro (angelo.decaro@gmail.com)
 */
public interface Question {

    boolean is(Object... params);
    
}
