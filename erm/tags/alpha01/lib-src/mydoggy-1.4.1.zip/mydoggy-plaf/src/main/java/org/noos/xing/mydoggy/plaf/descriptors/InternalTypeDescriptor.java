package org.noos.xing.mydoggy.plaf.descriptors;

import org.noos.xing.mydoggy.ToolWindowTypeDescriptor;

/**
 * @author Angelo De Caro (angelo.decaro@gmail.com)
 */
public interface InternalTypeDescriptor {

    ToolWindowTypeDescriptor cloneMe();

}
