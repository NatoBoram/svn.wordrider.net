package org.noos.xing.mydoggy.plaf.ui.cmp.event;

import java.util.EventListener;

/**
 * @author Angelo De Caro (angelo.decaro@gmail.com)
 */
public interface TabbedContentPaneListener extends EventListener {

    void tabbedContentPaneEventFired(TabbedContentPaneEvent event);

}