package org.noos.xing.mydoggy.itest;

/**
 * @author Angelo De Caro (angelo.decaro@gmail.com)
 */
public interface InteractiveTestRunner {

    void addInteractiveTest(InteractiveTest interactiveTest);

    void run();
}
