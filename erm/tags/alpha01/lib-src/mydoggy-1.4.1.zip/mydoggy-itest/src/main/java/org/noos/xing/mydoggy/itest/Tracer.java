package org.noos.xing.mydoggy.itest;

/**
 * @author Angelo De Caro (angelo.decaro@gmail.com)
 */
public interface Tracer {

    void start();

    void stop();

    interface Emitter {

        void emit(String text);
    }

}
