/**
 * Contains set of useful filters for image operations like Gausian or Fast or Star Blur or Color Tint filter.
 */
package org.jdesktop.swingx.image;

