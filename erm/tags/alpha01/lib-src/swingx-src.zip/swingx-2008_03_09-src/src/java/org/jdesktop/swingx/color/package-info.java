/**
 * Contains classes and interfaces used by the {@code JXGradientChooser}
 * component.
 */
package org.jdesktop.swingx.color;
